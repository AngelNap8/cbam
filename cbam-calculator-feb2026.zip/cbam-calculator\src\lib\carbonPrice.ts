// Centralized EU ETS carbon price configuration
// Update `price` and `lastUpdated` manually when you check the current rate.
// Source: https://tradingeconomics.com/commodity/carbon

export const EU_ETS_CONFIG = {
    price: 69.50,               // EUR per tonne CO₂ — as of March 2026
    lastUpdated: '2026-03-04',
    source: 'Trading Economics',
    sourceUrl: 'https://tradingeconomics.com/commodity/carbon',
};
